read -r -d '' help <<EOF
$ connect=\$(.../jdconnect.sh all user0/user0 localhost:3000)
   create connect folder in same folder as jdconnect.sh
   connect folder has files used in accessing server
   connect folder deleted if curl or logon fail
   $connect on success is path to connect folder or on failure is empty

$ .../jdreq.sh \$connect '"info schema"'
$ echo '"info summary"' > foo
$ jdreq.sh \$connect @foo

$ .../jdclose.sh \$connect
   logoff and delete connect folder

$ .../jdhelp.sh
EOF
echo "$help"
