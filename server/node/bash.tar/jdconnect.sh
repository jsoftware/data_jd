#!/bin/bash
set -eu
quit(){
 if [ -f "$p/jdclass" ]; then rm -r $p; fi
 exit 1;
}
if [ $# -ne 3 ]; then echo "jdconnect: incorrect number of arguments" >&2; exit 1; fi
p="$(dirname $(realpath -s $0))"/"$(uuidgen)/"
mkdir -p $p
echo "jdclient" > $p/jdclass
echo $1 > $p/dan
echo $3 > $p/host
result=$p/resultfile
cookie=$p/cookie
curl --no-progress-meter -k --data-binary "+ \"logon $2\"" -o $result -c $cookie -X POST -H Content-Type:application/octet-stream https://$3 2> $p/stderr || true
if [ -s $p/stderr ]; then  cat "$p/stderr" >&2; quit; fi
awk -F'\t' -v name="jds_cookie" '($6 == name) {printf "%s",$7}' $p/cookie > $p/cookievalue
if [ ! -s $p/cookievalue ]; then  echo "logon failed" >&2; quit; fi
echo $p # path to connect folder
