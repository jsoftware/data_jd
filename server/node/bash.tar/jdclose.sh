#!/bin/bash
set -eu
if [ ! -f "$1/jdclass" ]; then echo "bad connect folder"; exit 1; fi
if [ -f "$1/cookie" ]; then
 result=$1resultfile
 cookie=$1cookie
 host=$(cat $1/host)
 curl --no-progress-meter -k --data-binary "+ \"logoff\"" -o $result -b $cookie -X POST -H Content-Type:application/octet-stream https://$host || true
fi
rm -r $1
