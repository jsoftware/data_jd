#!/bin/bash
if [ ! -f "$1/jdclass" ]; then echo "bad connect folder"; exit 1; fi
post=$1/postfile
result=$1/resultfile
resultlz4=$1/resultfile.lz4
cookie=$1/cookie
host=$(cat $1/host)
dan=$(cat $1/dan)
arg=$2
if [[ "@" !=  "${2:0:1}" ]]; then echo $2 > $1/temp; arg=@$1/temp ; fi
printf "%s " $dan >  $post
lz4 -f -q -c "${arg:1}" >> $post
curl --no-progress-meter -k --data-binary @$post -o $resultlz4 -b $cookie -c $cookie -X POST -H Content-Type:application/octet-stream https://$host 2> $1/stderr || true
if [ -s $1/stderr ]; then  cat "$1/stderr" >&2; fi
read -n1 char <"$resultlz4"
if [[ "$char" == "{" ]]; then cp $resultlz4 $result; else lz4 -d -f -q $resultlz4 $result; fi
cat $result
